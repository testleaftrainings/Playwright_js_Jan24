export enum URLConstants{

    baseURL = "https://businesscentral.dynamics.com/?noSignUpCheck=1",
    homeURL = "https://businesscentral.dynamics.com/?company=CRONUS%20IN",
}