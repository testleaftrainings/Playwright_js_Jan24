export enum AppConstants{

    SF_URL = "https://login.salesforce.com/",
    INSTANCE_URL = "https://testleaf30-dev-ed.develop.lightning.force.com/lightning/setup/SetupOneHome/home",
    
}

export enum ToggleStates {
    ON = "ON",
    OFF = "OFF"
}