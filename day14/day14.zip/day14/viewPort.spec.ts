import { chromium, devices, test } from "@playwright/test";

test('Learning View Port', async () => {

    const myDevice = devices['iPhone 15'];
    const browser = await chromium.launch();
    const browserContext = await browser.newContext({
        ...myDevice,
        viewport: { width: 852, height: 393 }
    });
    const page = await browserContext.newPage();
    await page.goto("https://www.testleaf.com/");
    // await page.waitForTimeout(2000);
})