import { test } from "@playwright/test";

test('Learning Device Emulation', async ({ page }) => {

    await page.goto("https://www.testleaf.com/");
    await page.waitForTimeout(2000);
})