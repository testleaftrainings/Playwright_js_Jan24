import { test } from "@playwright/test";

test('Login - Leaftaps', async ({ page }) => {

    await page.goto("http://leaftaps.com/opentaps/control/main");

    // fill username, password
    await page.locator('#username').fill("demosalesmanager");
    await page.locator('#passwor').fill("crmsfa");

    // click login button
    await page.locator('.decorativeSubmit').click();
})