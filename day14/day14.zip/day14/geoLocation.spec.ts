import { test, expect, devices, chromium } from '@playwright/test';

// test.use({ locale: 'en-IN' });

test('test', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext({
  
      geolocation: { longitude: 139.6500, latitude: 35.6764 },
      permissions: ['geolocation']
    });
    const page = await context.newPage();
    await page.goto('https://www.openstreetmap.org');
    await page.locator('[aria-label="Show My Location"]').click();
    await page.waitForTimeout(15000);

});