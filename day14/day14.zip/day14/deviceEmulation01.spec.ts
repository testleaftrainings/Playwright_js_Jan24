import { chromium, devices, test } from "@playwright/test";

test('Learning Device Emulation', async () => {

    const myDevice = devices['Galaxy Note 3 landscape'];
    const browser = await chromium.launch();
    const browserContext = await browser.newContext({
        ...myDevice
    });
    const page = await browserContext.newPage();
    await page.goto("https://www.testleaf.com/");
    // await page.waitForTimeout(2000);
})